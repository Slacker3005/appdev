from wtforms import Form, StringField, RadioField, SelectField, TextAreaField, validators
from wtforms.fields import EmailField, DateField

class CreateUserForm(Form):
    area_id = StringField('Area Manager ID', [validators.Length(min=1, max=150), validators.DataRequired()])
    req_stock1 = StringField('Required Stock on Medicine ', [validators.Length(min=1, max=150), validators.DataRequired()])
    supp_comp = SelectField('Supplier Companies', [validators.DataRequired()], choices=[('', 'Select'), ('A', 'ASLAN Pharmaceuticals'), ('P', 'Alliance Pharm Pte Ltd')], default='')
    medicine_type = RadioField('Type of Medicine', choices=[('P', 'Panadol'), ('T', 'Tylenol'), ('A', 'Antacids')], default='')
    remarks = TextAreaField('Remarks', [validators.Optional()])

class CreateCustomerForm(Form):
    area_id = StringField('Branch Manager ID', [validators.Length(min=1, max=150), validators.DataRequired()])
    req_stock1 = StringField('Required Amount of Medicine', [validators.Length(min=1, max=150), validators.DataRequired()])
    supp_comp = SelectField('Branch Sector', [validators.DataRequired()], choices=[('', 'Select'), ('N', 'North'), ('S', 'South')], default='')
    email = EmailField('Email', [validators.Email(), validators.DataRequired()])
    date_joined = DateField('Date of Request', format='%Y-%m-%d')
    address = TextAreaField('Mailing Address', [validators.length(max=200), validators.DataRequired()])
    medicine_type = RadioField('Type of medicine', choices=[('P', 'Panadol'), ('T', 'Tylenol'), ('A', 'Antacids')], default='')
    remarks = TextAreaField('Remarks', [validators.Optional()])
